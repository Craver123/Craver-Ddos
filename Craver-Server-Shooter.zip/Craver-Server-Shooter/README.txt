<--- How To Use --->
1. start CMD
2.type : cd (path to file) and than press enter
3.type : python shoot.py -s (ip of victum)
